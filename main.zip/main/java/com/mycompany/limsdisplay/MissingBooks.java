package com.mycompany.limsdisplay;


import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class MissingBooks {
    private ArrayList<Book> books;
    private ArrayList<Barcode> barcodes;

    public MissingBooks(ArrayList<Book> books, ArrayList<Barcode> barcodes) {
        this.books = books;
        this.barcodes = barcodes;
    }

    public ArrayList<Book> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<Book> books) {
        this.books = books;
    }

    public ArrayList<Barcode> getBarcodes() {
        return barcodes;
    }

    public void setBarcodes(ArrayList<Barcode> barcodes) {
        this.barcodes = barcodes;
    }

    public MissingBooks() {
    }
    
}
