package com.mycompany.limsdisplay;


import java.sql.Timestamp;


public class Barcode {
    private String barcode;
    private int book_id;
    private Timestamp timestamp;
    private boolean is_Scanned;

    public Barcode() {
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public boolean isIs_Scanned() {
        return is_Scanned;
    }

    public void setIs_Scanned(boolean is_Scanned) {
        this.is_Scanned = is_Scanned;
    }
    
    


    
    
    
    
}
