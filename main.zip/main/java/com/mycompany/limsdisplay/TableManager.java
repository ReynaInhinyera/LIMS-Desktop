package com.mycompany.limsdisplay;


import java.awt.Color;
import java.awt.Component;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class TableManager {
    
    private JTable list_display;
    private JLabel lbl_no_users, db_total, scan_total, unscan_total;

    public TableManager() {
    }

    public TableManager(JTable tbl_online_users, JLabel lbl_no_users) {
         this.list_display = tbl_online_users;
         this.lbl_no_users = lbl_no_users;
    }

    public TableManager(JTable book_list_display, JLabel db_total, JLabel scan_total, 
            JLabel unscan_total) {
        this.list_display = book_list_display;
        this.db_total = db_total;
        this.scan_total = scan_total;
        this.unscan_total = unscan_total;
    }

    public JTable getList_display() {
        return list_display;
    }

    public void setList_display(JTable list_display) {
        this.list_display = list_display;
    }

    public JLabel getDb_total() {
        return db_total;
    }

    public void setDb_total(JLabel db_total) {
        this.db_total = db_total;
    }

    public JLabel getScan_total() {
        return scan_total;
    }

    public void setScan_total(JLabel scan_total) {
        this.scan_total = scan_total;
    }

    public JLabel getUnscan_total() {
        return unscan_total;
    }

    public void setUnscan_total(JLabel unscan_total) {
        this.unscan_total = unscan_total;
    }
    
    

    public JTable getBook_list_display() {
        return list_display;
    }

    public void setBook_list_display(JTable book_list_display) {
        this.list_display = book_list_display;
    }

    public JLabel getLbl_no_users() {
        return lbl_no_users;
    }

    public void setLbl_no_users(JLabel lbl_no_users) {
        this.lbl_no_users = lbl_no_users;
    }
    
    public TableManager(JTable book_list_display) {
        this.list_display = book_list_display;
    }
    
    private DefaultTableModel setOnlineTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"ID", "Name", "Permission"};
        model.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(model);
        return model;
    }
    
    private DefaultTableModel setUserTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"ID", "Name", "Online Status", 
            "Permission"};
        model.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(model);
        return model;
    }
    
    public void addUsers(ArrayList<User> users) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setOnlineTable();
        
        for (User user : users) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            data.add(user.getId());
            data.add(user.getName());
            
            if(user.isEnabled()){
                data.add("ENABLED");
            
            } else {
                data.add("BLOCKED");
            }
            
            model.addRow(data);
        }
        
        lbl_no_users.setText("Connected Users: " + String.valueOf(users.size()));
        updateRowHeights();
    }
    
    public void manageUsers(ArrayList<User> users) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setUserTable();
        
        for (User user : users) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            data.add(user.getId());
            data.add(user.getName());
            
            if(user.isOnlineStatus()){
                data.add("ONLINE");
            } else {
                data.add("OFFLINE");
            }
            
            if(user.isEnabled()){
                data.add("ENABLED");
            
            } else {
                data.add("BLOCKED");
            }
            
            model.addRow(data);
        }
       updateRowHeights();
    }
    
    //scan status - "completed", "on progress"
    private DefaultTableModel setTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"Barcodes", "Title Statement", "Call Number", "Total Number", "Total Scanned", "Status", "Date & Time Scanned"};
        model.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(model);
        return model;
    }
    
    public void addBook(ArrayList<Book> books, ArrayList<Barcode> barcodes) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setTable();
        int total_no = 0, scanned_no = 0, unscanned_no = 0, row_num = 0;
        
        for (Book book : books) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            
            String separator = "";
            StringBuilder barcodeBuilder = new StringBuilder();
            StringBuilder timestampBuilder = new StringBuilder();
            
            for (Barcode barcode : barcodes) {              //for each object (object barcode created) which was added in the collection, do code below it
                if (barcode.getBook_id() == book.getId()) {
                    barcodeBuilder.append(separator);
                    barcodeBuilder.append(barcode.getBarcode());
                    
                    timestampBuilder.append(separator);
                    timestampBuilder.append(barcode.getTimestamp());
                    separator = ", ";
                }
            }
            data.add(barcodeBuilder.toString());
            data.add(book.getTitle());
            data.add(book.getCall_no());
            data.add(book.getTotal_no());
            data.add(book.getScanned_no());
            
            total_no = total_no + book.getTotal_no();
            scanned_no = scanned_no + book.getScanned_no();
            unscanned_no = total_no - scanned_no;
            
            if (book.getScanned_no() < book.getTotal_no()) {
                data.add("");
            }
            else {
                data.add("COMPLETE");
            }
            row_num = row_num + 1;
            data.add(timestampBuilder.toString());
            model.addRow(data);
        }
        db_total.setText("Total in database: " + String.valueOf(total_no));
        scan_total.setText("Total Scanned: " + String.valueOf(scanned_no));
        unscan_total.setText("Total Unscanned: " + String.valueOf(unscanned_no));
        
        list_display.setDefaultRenderer(Object.class, new SetCellRenderer());
        updateRowHeights();
        
    }
    
    private static class SetCellRenderer implements TableCellRenderer {
        private DefaultTableCellRenderer renderer =  new DefaultTableCellRenderer();

        public SetCellRenderer() {
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, 
                Object value, boolean isSelected, boolean hasFocus, int row, 
                int column) {
            Component c = renderer.getTableCellRendererComponent(table, value, 
                    hasFocus, hasFocus, row, column);
            
            //changes color when that row is selected
            if(isSelected){
                    c.setBackground(Color.YELLOW);
                    c.setForeground(Color.BLACK);

            //alternates color each row by default
            } else {
                if (row%2 == 0){
                    c.setBackground(Color.WHITE);

                }
                else {
                    c.setBackground(Color.CYAN);
                }     
            }
            

///////////CHANGE THE "PUBLISHED?" to whatever you named in the header
       
            if(table.getColumnModel().getColumn(column).getIdentifier()
                    .equals("Status")){
                if(value.toString().equals("COMPLETE")){
                    c.setBackground(Color.GREEN);
                }
                else {
                    c.setBackground(Color.RED);
                }
            }
            
            return c;
        }
    }
    
    private DefaultTableModel setTableFinal() {
        DefaultTableModel finalmodel = new DefaultTableModel (0, 0);
        String header[] = new String[]{"Title Statement", "Call Number", "Barcode"};
        finalmodel.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(finalmodel);
        return finalmodel;
    }
    
    public void addBookFinal(String section, String category) throws SQLException {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setTableFinal();
        
        ArrayList<Book> books = new DBConfig().getBooks(section);
        ArrayList<Barcode> barcodes = new DBConfig().getBarcodes();
        
        for (Book book : books) {       //for each - for unknown count in array; for each scans through the whole collection
            for (Barcode barcode : barcodes) {
                if (category.equals("Scanned")){
                    if (book.getId() == barcode.getBook_id() && barcode.isIs_Scanned())
                    {
                        Vector<Object> data = new Vector<Object>();

                        data.add(book.getTitle());
                        data.add(book.getCall_no());
                        data.add(barcode.getBarcode());
            
                        model.addRow(data);
                    }
                } else if (category.equals("Missing")){
                    if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned())
                    {
                        Vector<Object> data = new Vector<Object>();

                        data.add(book.getTitle());
                        data.add(book.getCall_no());
                        data.add(barcode.getBarcode());
            
                        model.addRow(data);
                    }
                }
                
            }
            
        }
        updateRowHeights();
        
    }
    
    private void updateRowHeights()
{
    for (int row = 0; row < list_display.getRowCount(); row++)
    {
        int rowHeight = list_display.getRowHeight();

        for (int column = 0; column < list_display.getColumnCount(); column++)
        {
            Component comp = list_display.prepareRenderer(list_display.getCellRenderer(row, column), row, column);
            rowHeight = 30;
        }

        list_display.setRowHeight(row, rowHeight);
    }
}
    
    
}
