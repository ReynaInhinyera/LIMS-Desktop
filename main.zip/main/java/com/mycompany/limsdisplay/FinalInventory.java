package com.mycompany.limsdisplay;


import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class FinalInventory extends javax.swing.JFrame {
    
private TableManager tableman;

private String[] sections = {"Circulation", "Reference", "Filipiniana", "American Corner"};
int circ_no_data = 0;
int circ_no_scan = 0;
int ref_no_data = 0;
int ref_no_scan = 0; 
int fili_no_data = 0;
int fili_no_scan = 0;
int ac_no_data = 0;
int ac_no_scan = 0;
int circ_no_miss = 0;
int ref_no_miss = 0;
int fili_no_miss = 0;
int ac_no_miss = 0;
int total_no_data = 0;
int total_no_scan = 0;
int total_no_miss = 0;

    
    public FinalInventory() throws SQLException {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getBooks();
        displayResults();
        loadBooks("All sections");
        getDateTime(); 
    }

    private void loadBooks(String section) throws SQLException{
        tableman = new TableManager(booklist_final_inv);
        DBConfig dbcon = new DBConfig();
        tableman.addBookFinal(section);
    } 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        circ_miss = new javax.swing.JLabel();
        circ_database = new javax.swing.JLabel();
        circ_scan = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        ref_database = new javax.swing.JLabel();
        ref_scan = new javax.swing.JLabel();
        ref_miss = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        fili_database = new javax.swing.JLabel();
        fili_scan = new javax.swing.JLabel();
        fili_miss = new javax.swing.JLabel();
        ac_miss = new javax.swing.JLabel();
        ac_scan = new javax.swing.JLabel();
        ac_database = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        total_database = new javax.swing.JLabel();
        total_scan = new javax.swing.JLabel();
        total_miss = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        booklist_final_inv = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        section_select = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 55)); // NOI18N
        jLabel1.setText("Mobile Library Inventory Scanner");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 40)); // NOI18N
        jLabel2.setText("Inventory Report");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 90, -1, -1));

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Arial Narrow", 1, 48)); // NOI18N
        jLabel4.setText("Statistics");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 0, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel5.setText("Circulation:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, -1, -1));

        circ_miss.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        circ_miss.setText("Copies missing/unscanned:");
        jPanel1.add(circ_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, -1, -1));

        circ_database.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        circ_database.setText("Copies in database:");
        jPanel1.add(circ_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, -1, -1));

        circ_scan.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        circ_scan.setText("Copies scanned:");
        jPanel1.add(circ_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, -1, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel9.setText("Reference:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        ref_database.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        ref_database.setText("Copies in database:");
        jPanel1.add(ref_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, -1, -1));

        ref_scan.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        ref_scan.setText("Copies scanned:");
        jPanel1.add(ref_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, -1, -1));

        ref_miss.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        ref_miss.setText("Copies missing/unscanned:");
        jPanel1.add(ref_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel13.setText("Filipiniana:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, -1, -1));

        fili_database.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        fili_database.setText("Copies in database:");
        jPanel1.add(fili_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, -1, -1));

        fili_scan.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        fili_scan.setText("Copies scanned:");
        jPanel1.add(fili_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 400, -1, -1));

        fili_miss.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        fili_miss.setText("Copies missing/unscanned:");
        jPanel1.add(fili_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 430, -1, -1));

        ac_miss.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        ac_miss.setText("Copies missing/unscanned:");
        jPanel1.add(ac_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 570, -1, -1));

        ac_scan.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        ac_scan.setText("Copies scanned:");
        jPanel1.add(ac_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 540, -1, -1));

        ac_database.setFont(new java.awt.Font("Arial Narrow", 0, 24)); // NOI18N
        ac_database.setText("Copies in database:");
        jPanel1.add(ac_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 510, -1, -1));

        jLabel20.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel20.setText("American Corner:");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 480, -1, -1));

        jLabel21.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel21.setText("TOTAL:");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 620, -1, -1));

        total_database.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        total_database.setText("Copies in database:");
        jPanel1.add(total_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 650, -1, -1));

        total_scan.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        total_scan.setText("Copies scanned:");
        jPanel1.add(total_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 680, -1, -1));

        total_miss.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        total_miss.setText("Copies missing/unscanned:");
        jPanel1.add(total_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 710, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 610, 760));

        booklist_final_inv.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        booklist_final_inv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title Statement", "Call Number", "Barcode"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(booklist_final_inv);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 300, 1310, 570));

        jButton2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 48)); // NOI18N
        jButton2.setText("BACK");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 910, 190, 60));

        jLabel7.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        jLabel7.setText("As of:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 150, -1, -1));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 55)); // NOI18N
        jLabel8.setText("Mobile Library Inventory Scanner");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, -1, -1));

        jLabel10.setFont(new java.awt.Font("Arial", 1, 40)); // NOI18N
        jLabel10.setText("Inventory Report");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 90, -1, -1));

        jLabel12.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        jLabel12.setText("As of:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 150, -1, -1));

        jLabel17.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\LIMS logo (200).png")); // NOI18N
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\jtb logo (300).png")); // NOI18N
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(1610, 10, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        jLabel3.setText("<insert date>");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 150, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 240));

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        jButton1.setText("Missing Books Only");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 40, 300, 50));

        jButton3.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 24)); // NOI18N
        jButton3.setText("Scanned Books Only");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, 300, 50));

        jLabel15.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\spreadsheet 72.png")); // NOI18N
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        jLabel16.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel16.setText("Generate Inventory Report:");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 870, 1060, 130));

        jPanel4.setBackground(new java.awt.Color(51, 51, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        section_select.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        section_select.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "All sections", "Circulation", "Reference", "American Corner", "Filipiniana" }));
        section_select.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                section_selectActionPerformed(evt);
            }
        });
        jPanel4.add(section_select, new org.netbeans.lib.awtextra.AbsoluteConstraints(1040, 10, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Select Section:");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 10, -1, -1));

        jComboBox1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Missing", "Scanned" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        jPanel4.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, -1, -1));

        jLabel14.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Select Category:");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 240, 1310, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    try {
        excelGen();
    } catch (IOException ex) {
        Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SQLException ex) {
        Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void section_selectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_section_selectActionPerformed
    try {
        loadBooks((String) section_select.getSelectedItem());
    } catch (SQLException ex) {
        Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_section_selectActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

    try {
        Table table = new Table();
        table.show();
        dispose();
    } catch (SQLException ex) {
        Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
    }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new FinalInventory().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ac_database;
    private javax.swing.JLabel ac_miss;
    private javax.swing.JLabel ac_scan;
    private javax.swing.JTable booklist_final_inv;
    private javax.swing.JLabel circ_database;
    private javax.swing.JLabel circ_miss;
    private javax.swing.JLabel circ_scan;
    private javax.swing.JLabel fili_database;
    private javax.swing.JLabel fili_miss;
    private javax.swing.JLabel fili_scan;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel ref_database;
    private javax.swing.JLabel ref_miss;
    private javax.swing.JLabel ref_scan;
    private javax.swing.JComboBox section_select;
    private javax.swing.JLabel total_database;
    private javax.swing.JLabel total_miss;
    private javax.swing.JLabel total_scan;
    // End of variables declaration//GEN-END:variables

    private void getBooks() throws SQLException {
        for (String section : sections) {
            ArrayList<Book> books = new DBConfig().getBooks(section);             //step 2 and 3 (get books from db by section; place books in list)
            for (Book book : books) {                   //step 4 (iterate through the list of books)
                switch (section) {
                    case "Circulation":
                        circ_no_data = circ_no_data + book.getTotal_no();
                        circ_no_scan = circ_no_scan + book.getScanned_no();
                        break;
                    case "Reference":
                        ref_no_data = ref_no_data + book.getTotal_no();
                        ref_no_scan = ref_no_scan + book.getScanned_no();
                        break;
                    case "Filipiniana":
                        fili_no_data = fili_no_data + book.getTotal_no();
                        fili_no_scan = fili_no_scan + book.getScanned_no();
                        break;
                    case "American Corner":
                        ac_no_data = ac_no_data + book.getTotal_no();
                        ac_no_scan = ac_no_scan + book.getScanned_no();
                        break;
                }
            }
        }
        
    }

    private void displayResults() {
        circ_no_miss = circ_no_data - circ_no_scan;
        circ_database.setText("Copies in database: " + String.valueOf(circ_no_data));
        circ_scan.setText("Copies scanned: " + String.valueOf(circ_no_scan));
        circ_miss.setText("Copies missing/unscanned: " + String.valueOf(circ_no_miss));
        
        ref_no_miss = ref_no_data - ref_no_scan;
        ref_database.setText("Copies in database: " + String.valueOf(ref_no_data));
        ref_scan.setText("Copies scanned: " + String.valueOf(ref_no_scan));
        ref_miss.setText("Copies missing/unscanned: " + String.valueOf(ref_no_miss));
        
        fili_no_miss = fili_no_data - fili_no_scan;
        fili_database.setText("Copies in database: " + String.valueOf(fili_no_data));
        fili_scan.setText("Copies scanned: " + String.valueOf(fili_no_scan));
        fili_miss.setText("Copies missing/unscanned: " + String.valueOf(fili_no_miss));
        
        ac_no_miss = ac_no_data - ac_no_scan;
        ac_database.setText("Copies in database: " + String.valueOf(ac_no_data));
        ac_scan.setText("Copies scanned: " + String.valueOf(ac_no_scan));
        ac_miss.setText("Copies missing/unscanned: " + String.valueOf(ac_no_miss));
        
        total_no_data = circ_no_data + ref_no_data + fili_no_data + ac_no_data;
        total_no_scan = circ_no_scan + ref_no_scan + fili_no_scan + ac_no_scan;
        total_no_miss = circ_no_miss + ref_no_miss + fili_no_miss + ac_no_miss;
        total_database.setText("Copies in database: " + String.valueOf(total_no_data));
        total_scan.setText("Copies scanned: " + String.valueOf(total_no_scan));
        total_miss.setText("Copies missing/unscanned: " + String.valueOf(total_no_miss));
        
    }
    
    private void getDateTime(){
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        String dateTime = dateFormat.format(new Date());
        
        jLabel3.setText(dateTime);
    }
    
    private void excelGen() throws FileNotFoundException, IOException, SQLException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet1 = workbook.createSheet("Statistics");
        Sheet sheet2 = workbook.createSheet("Circulation");
        Sheet sheet3 = workbook.createSheet("Reference");
        Sheet sheet4 = workbook.createSheet("American Corner");
        Sheet sheet5 = workbook.createSheet("Filipiniana");
        
        String[] columns1 = {"Section", "Total Books", "Total Scanned", "Total Missing"};
        Row headerRow1 = sheet1.createRow(0);
        
        for (int i = 0; i < columns1.length; i++) {
            Cell cell1 = headerRow1.createCell(i);
            cell1.setCellValue(columns1[i]);
        }
        
        int rowNum = 1;
        
        for (int i = 0; i < 5; i++) {
            Row row = sheet1.createRow(rowNum++);
            if(i == 0) {
                row.createCell(0).setCellValue("Circulation");
                row.createCell(1).setCellValue(circ_no_data);
                row.createCell(2).setCellValue(circ_no_scan);
                row.createCell(3).setCellValue(circ_no_miss);
            }
            if (i == 1) {
                row.createCell(0).setCellValue("Reference");
                row.createCell(1).setCellValue(ref_no_data);
                row.createCell(2).setCellValue(ref_no_scan);
                row.createCell(3).setCellValue(ref_no_miss);
            }
            if (i == 2) {
                row.createCell(0).setCellValue("American Corner");
                row.createCell(1).setCellValue(ac_no_data);
                row.createCell(2).setCellValue(ac_no_scan);
                row.createCell(3).setCellValue(ac_no_miss);
            }
            if (i == 3) {
                row.createCell(0).setCellValue("Filipiniana");
                row.createCell(1).setCellValue(fili_no_data);
                row.createCell(2).setCellValue(fili_no_scan);
                row.createCell(3).setCellValue(fili_no_miss);
            }
            if (i == 4) {
                row.createCell(0).setCellValue("GRAND TOTAL");
                row.createCell(1).setCellValue(total_no_data);
                row.createCell(2).setCellValue(total_no_scan);
                row.createCell(3).setCellValue(total_no_miss);
            }
        }
        
        for(int i = 0; i < columns1.length; i++) {
            sheet1.autoSizeColumn(i);
        }
        
        String[] columns2 = {"Barcode", "Title", "Call number"};
        Row headerRow2 = sheet2.createRow(0);
        
        for (int i = 0; i < columns2.length; i++) {
            Cell cell2 = headerRow2.createCell(i);
            cell2.setCellValue(columns2[i]);
        }
        
        int rowNum2 = 1;
        
        ArrayList<Book> circ_books = new DBConfig().getBooks("Circulation");
        ArrayList<Barcode> circ_barcodes = new DBConfig().getBarcodes();
        for (Book book : circ_books) {
            for (Barcode barcode : circ_barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned()){
                    Row row = sheet2.createRow(rowNum2++);
                    row.createCell(0).setCellValue(barcode.getBarcode());
                    row.createCell(1).setCellValue(book.getTitle());
                    row.createCell(2).setCellValue(book.getCall_no());
                }               
            }
        }
        
        for(int i = 0; i < columns2.length; i++) {
            sheet2.autoSizeColumn(i);
        }
        
        String[] columns3 = {"Barcode", "Title", "Call number"};
        Row headerRow3 = sheet3.createRow(0);
        
        for (int i = 0; i < columns3.length; i++) {
            Cell cell3 = headerRow3.createCell(i);
            cell3.setCellValue(columns3[i]);
        }
        
        int rowNum3 = 1;
        
        ArrayList<Book> ref_books = new DBConfig().getBooks("Reference");
        ArrayList<Barcode> ref_barcodes = new DBConfig().getBarcodes();
        for (Book book : ref_books) {
            for (Barcode barcode : ref_barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned()){
                    Row row = sheet3.createRow(rowNum3++);
                    row.createCell(0).setCellValue(barcode.getBarcode());
                    row.createCell(1).setCellValue(book.getTitle());
                    row.createCell(2).setCellValue(book.getCall_no());
                }               
            }
        }
        
        for(int i = 0; i < columns3.length; i++) {
            sheet3.autoSizeColumn(i);
        }
        
        String[] columns4 = {"Barcode", "Title", "Call number"};
        Row headerRow4 = sheet4.createRow(0);
        
        for (int i = 0; i < columns4.length; i++) {
            Cell cell4 = headerRow4.createCell(i);
            cell4.setCellValue(columns4[i]);
        }
        
        int rowNum4 = 1;
        
        ArrayList<Book> ac_books = new DBConfig().getBooks("American Corner");
        ArrayList<Barcode> ac_barcodes = new DBConfig().getBarcodes();
        for (Book book : ac_books) {
            for (Barcode barcode : ac_barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned()){
                    Row row = sheet4.createRow(rowNum4++);
                    row.createCell(0).setCellValue(barcode.getBarcode());
                    row.createCell(1).setCellValue(book.getTitle());
                    row.createCell(2).setCellValue(book.getCall_no());
                }               
            }
        }
        
        for(int i = 0; i < columns4.length; i++) {
            sheet4.autoSizeColumn(i);
        }
        
        String[] columns5 = {"Barcode", "Title", "Call number"};
        Row headerRow5 = sheet5.createRow(0);
        
        for (int i = 0; i < columns5.length; i++) {
            Cell cell5 = headerRow5.createCell(i);
            cell5.setCellValue(columns5[i]);
        }
        
        int rowNum5 = 1;
        
        ArrayList<Book> fili_books = new DBConfig().getBooks("Filipiniana");
        ArrayList<Barcode> fili_barcodes = new DBConfig().getBarcodes();
        for (Book book : fili_books) {
            for (Barcode barcode : fili_barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned()){
                    Row row = sheet5.createRow(rowNum5++);
                    row.createCell(0).setCellValue(barcode.getBarcode());
                    row.createCell(1).setCellValue(book.getTitle());
                    row.createCell(2).setCellValue(book.getCall_no());
                }               
            }
        }
        
        for(int i = 0; i < columns5.length; i++) {
            sheet5.autoSizeColumn(i);
        }
        
        FileOutputStream fileOut = new FileOutputStream("Final Inventory.xlsx");
        System.out.println("Excel File Generated!");
        workbook.write(fileOut);
        fileOut.close();
        
        workbook.close();
        
        Desktop.getDesktop().open(new File("Final Inventory.xlsx"));
    }
    

}
