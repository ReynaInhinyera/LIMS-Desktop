package com.mycompany.limsdisplay;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import org.apache.commons.codec.digest.DigestUtils;


public class DBConfig {
    
    private Connection c;         //Connection connects to postgre database
    private Statement stmt;            //Statement - what to do; request; CRUD

    public DBConfig() {
        try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/db_inventory",
            "postgres", "pgadmin");
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }         //try - try the code; catch - catches the error
      System.out.println("Opened database successfully");
    }

    public DBConfig(Connection c) {        
        try {
         Class.forName("org.postgresql.Driver");
         this.c = c;
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }
      System.out.println("Opened database successfully");
    }
    
    public ArrayList<Book> getBooks(String section) throws SQLException {             //this whole does SQL database operation. if there are any errors, there is an automatic catch or disregards error.
        stmt = c.createStatement();                     //create request
        ResultSet rs;
        
        if (section.equals("All sections")) {
            rs = stmt.executeQuery("SELECT id, title, total_no, no_scanned, call_no, section " 
                + "FROM public.tbl_inventory AS inv "
                + "ORDER BY \"timestamp\" DESC;");         //execute request or statement
        }
        else {
            rs = stmt.executeQuery("SELECT id, title, total_no, no_scanned, call_no, section " 
                + "FROM public.tbl_inventory "
                + "WHERE section = '" + section + "' "
                + "ORDER BY \"timestamp\" DESC;");         //execute request or statement
        }
        
        ArrayList<Book> books = new ArrayList<Book>();
        
        while (rs.next()) {             //while there is still a next row, it will execute this loop
            Book book = new Book();                 //create new object
            
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setTotal_no(rs.getInt("total_no"));
            book.setScanned_no(rs.getInt("no_scanned"));
            book.setCall_no(rs.getString("call_no"));
            book.setSection(rs.getString("section"));   //these six sets values
            books.add(book);        //puts inside the new created collection (arraylist)
        }
        
        rs.close();
        stmt.close();
        c.close();
        //these three indicates that the query has ended
        
        System.out.println("Get books done successfully!");
        
        return books;
    }
    
    public boolean getAdmin(int id, String pw) throws SQLException {             //this whole does SQL database operation. if there are any errors, there is an automatic catch or disregards error.
        stmt = c.createStatement();                     //create request
        ResultSet rs;
        rs = stmt.executeQuery("SELECT id, password FROM public.tbl_admin;");         //execute request or statement
        boolean checkAdmin = false;
        
        while (rs.next()) {             //while there is still a next row, it will execute this loop
            int db_id = rs.getInt("id");
            String db_pw = rs.getString("password");
            
            if(db_id == id && db_pw.equals(DigestUtils.md5Hex(pw))){
                checkAdmin = true;
            } 
            
        }
        
        rs.close();
        stmt.close();
        c.close();
        //these three indicates that the query has ended
        
        return checkAdmin;
    }
    
    public boolean confirmPassword(String pw) throws SQLException {             //this whole does SQL database operation. if there are any errors, there is an automatic catch or disregards error.
        stmt = c.createStatement();                     //create request
        ResultSet rs;
        rs = stmt.executeQuery("SELECT password FROM public.tbl_admin;");         //execute request or statement
        boolean checkAdmin = false;
        
        while (rs.next()) {             //while there is still a next row, it will execute this loop
            String db_pw = rs.getString("password");
            
            if(db_pw.equals(DigestUtils.md5Hex(pw))){
                checkAdmin = true;
            } else {
                checkAdmin = false;
            }
        }
        
        rs.close();
        stmt.close();
        c.close();
        //these three indicates that the query has ended
        
        return checkAdmin;
    }
    
    public ArrayList<Barcode> getBarcodes() throws SQLException {
        stmt = c.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT barcode, book_id, \"timestamp\", is_scanned "
                + "FROM tbl_barcode;");
        ArrayList<Barcode> barcodes = new ArrayList<Barcode>();
        
        while (rs.next()) {
            Barcode barcode = new Barcode();
            barcode.setBarcode(rs.getString("barcode"));
            barcode.setBook_id(rs.getInt("book_id"));
            barcode.setTimestamp(rs.getTimestamp("timestamp"));
            
            if (rs.getString("is_scanned").equals("1")){
                barcode.setIs_Scanned(true);
            } else if (rs.getString("is_scanned").equals("0")){
                barcode.setIs_Scanned(false);
            }
            
            barcodes.add(barcode);              //<name of collection>.add(what is done before)
        }
        
        rs.close();
        stmt.close();
        c.close();
        
        System.out.println("Get barcodes done successfully");
        
        return barcodes;
    }
    
    public ArrayList<User> getOnlineUsers() throws SQLException {
        stmt = c.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT id, name, permission FROM public.tbl_users "
                + "WHERE online_status = '1';");
        ArrayList<User> users = new ArrayList<User>();
        
        while (rs.next()) {
            User user = new User();
            user.setId(rs.getInt("id"));
            user.setName(rs.getString("name"));
            
            if(rs.getString("permission").equals("0")){
                user.setEnabled(false);
            } else if (rs.getString("permission").equals("1")){
                user.setEnabled(true);
            }
            users.add(user);
        }
        
        rs.close();
        stmt.close();
        c.close();
        
        System.out.println("Get online users done successfully");      
        return users;
    }
    
    public ArrayList<User> getUsers() throws SQLException {
        stmt = c.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT id, name, permission, "
                + "online_status FROM public.tbl_users;");
        ArrayList<User> users = new ArrayList<User>();
        
        while (rs.next()) {
            User user = new User();
            user.setId(rs.getInt("id"));
            user.setName(rs.getString("name"));
            
            if(rs.getString("online_status").equals("0")){
                user.setOnlineStatus(false);
            } else if (rs.getString("online_status").equals("1")){
                user.setOnlineStatus(true);
            }
            
            if(rs.getString("permission").equals("0")){
                user.setEnabled(false);
            } else if (rs.getString("permission").equals("1")){
                user.setEnabled(true);
            }
            users.add(user);
        }
        
        rs.close();
        stmt.close();
        c.close();
        
        System.out.println("Get users done successfully");      
        return users;
    }
    
    public void enableUser(int id) throws SQLException {
        stmt = c.createStatement();   
        stmt.executeUpdate("UPDATE public.tbl_users "
            + "SET permission='1' "
            + "WHERE id="
            + id);
        
        stmt.close();
        c.close();
    }
    
    public void disableUser(int id) throws SQLException {
        stmt = c.createStatement();   
        stmt.executeUpdate("UPDATE public.tbl_users "
            + "SET permission='0' "
            + "WHERE id="
            + id);
        
        stmt.close();
        c.close();
    }
    
    public void addUser(String id, String password, String name) throws SQLException {
        stmt = c.createStatement();   
        stmt.executeUpdate("INSERT INTO public.tbl_users (" +
	"id, password, online_status, permission, name) " +
	"VALUES (" + id + ", '" + password + "', '" + 0 + "', '" + 1 + "', '" + name + "');");
        
        stmt.close();
        c.close();
    }
    
    public void deleteUser(String id) throws SQLException {
        stmt = c.createStatement();   
        stmt.executeUpdate("DELETE FROM tbl_users WHERE id = " + id);
        
        stmt.close();
        c.close();
    }
    
    public void deleteBook(String barcode) throws SQLException {
        int book_id = getBookId(barcode);
        
        stmt = c.createStatement();   
        stmt.executeUpdate("DELETE FROM tbl_barcode WHERE barcode = '" + barcode + "';");      
        stmt.close();
            
        c.close();
    }
    
    public int getBookId(String barcode) throws SQLException {
        stmt = c.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT book_id, is_scanned FROM public.tbl_barcode "
                + "WHERE barcode = '" + barcode + "';");
        int book_id = 0, total_no = 0, scanned_no = 0;
        String is_scanned = "";
        
        while (rs.next()) {
            book_id = rs.getInt("book_id");
            is_scanned = rs.getString("is_scanned");
        }
        
        rs.close();
        
        rs = stmt.executeQuery("SELECT total_no, no_scanned FROM public.tbl_inventory "
                + "WHERE id = " + book_id + ";");
        
        while (rs.next()) {
            total_no = Integer.parseInt(rs.getString("total_no"));
            scanned_no = Integer.parseInt(rs.getString("no_scanned"));
        }
        
        if (total_no > 1 && is_scanned.equals("1")){
            total_no--;
            scanned_no--;
            stmt.executeUpdate("UPDATE tbl_inventory SET total_no = '" + String.valueOf(total_no) +
                    "', no_scanned = '" + String.valueOf(scanned_no) + "' "
                    + "WHERE id = " + book_id + ";");      
            stmt.close();
        
        } else if (total_no > 1 && is_scanned.equals("0")){
            total_no--;
            stmt.executeUpdate("UPDATE tbl_inventory SET total_no = '" + String.valueOf(total_no) +
                    "' WHERE id = " + book_id + ";");      
            stmt.close();
        
        } else if (total_no == 1){
            stmt.executeUpdate("DELETE FROM tbl_inventory WHERE id = " + book_id + ";");      
            stmt.close();
        }
        
        return book_id;
    }
    
    public void startNewInventory() throws SQLException {
        stmt = c.createStatement();   
        stmt.executeUpdate("UPDATE public.tbl_inventory "
            + "SET no_scanned='0'; ");
        
        stmt.close();
        c.close();
    }
    
    public void startNewBarcode() throws SQLException {
        stmt = c.createStatement();       
        stmt.executeUpdate("UPDATE public.tbl_barcode "
            + "SET is_scanned='0'; ");
        
        stmt.close();
        c.close();
    }
    
    public void updatePassword(String password, String id) throws SQLException {
        stmt = c.createStatement();       
        stmt.executeUpdate("UPDATE public.tbl_users "
            + "SET password=' " + password + "' WHERE id = " + id + ";");
        
        stmt.close();
        c.close();
    }
    
    public MissingBooks getBooksFinal() throws SQLException {             //this whole does SQL database operation. if there are any errors, there is an automatic catch or disregards error.
        stmt = c.createStatement();                     //create request
        ResultSet rs;
        
        rs = stmt.executeQuery("SELECT id, title, br.barcode, call_no, section "
            + "FROM tbl_inventory AS inv " 
            + "INNER JOIN tbl_barcode AS br "
            + "ON br.book_id = inv.id "
            + "WHERE br.is_scanned = '0' "); 
        
        MissingBooks missing_books = new MissingBooks();
        
        ArrayList<Book> books = new ArrayList<Book>();
        ArrayList<Barcode> barcodes = new ArrayList<Barcode>();
        
        while (rs.next()) {             //while there is still a next row, it will execute this loop
            Book book = new Book();                 //create new object
            Barcode barcode = new Barcode();
            
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setCall_no(rs.getString("call_no"));
            book.setSection(rs.getString("section"));
            barcode.setBook_id(rs.getInt("id"));
            barcode.setBarcode(rs.getString("barcode"));
            barcodes.add(barcode);
            books.add(book);        //puts inside the new created collection (arraylist)
        }
        
        missing_books.setBarcodes(barcodes);
        missing_books.setBooks(books);
        
        rs.close();
        stmt.close();
        c.close();
        //these three indicates that the query has ended
        
        System.out.println("Final inventory generated!");
        
        return missing_books;
    }
}
