package com.mycompany.limsdisplay;


import java.awt.Dialog;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class IntroSession extends javax.swing.JFrame {
    private TableManager tm;
    private PGListener listener;

    public IntroSession() throws UnknownHostException, SQLException {
        initComponents();
        showIP();     
        showOnlineUsers();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        listener = new PGListener(tm, "users");
        listener.start();
    }
    
    private void showIP() throws UnknownHostException {
         InetAddress inetAddress = InetAddress.getLocalHost();
         System.out.println("IP Address: " + inetAddress.getHostAddress());
         System.out.println("Host Name: " + inetAddress.getHostName());
            
         lbl_no_users.setText("Host Name: " + inetAddress.getHostName());
         insert_ip.setText(inetAddress.getHostAddress());
    }

     private void showOnlineUsers() throws SQLException {
        tm = new TableManager(tbl_online_users, lbl_no_users);
        tm.addUsers(new DBConfig().getOnlineUsers());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lbl_no_users = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_online_users = new javax.swing.JTable();
        btn_enable = new javax.swing.JButton();
        logout_button = new javax.swing.JButton();
        btn_disable = new javax.swing.JButton();
        user_button = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        sessionButton = new javax.swing.JButton();
        cont_inv_button1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        insert_ip = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1000));
        setPreferredSize(new java.awt.Dimension(1920, 1000));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, -1, -1));

        lbl_no_users.setFont(new java.awt.Font("Arial Black", 1, 32)); // NOI18N
        lbl_no_users.setText("Connected Users:");
        jPanel1.add(lbl_no_users, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, -1, -1));

        tbl_online_users.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        tbl_online_users.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Name", "Permission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_online_users);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 150, 830, 300));

        btn_enable.setFont(new java.awt.Font("Arial Narrow", 1, 30)); // NOI18N
        btn_enable.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\enable 72.png")); // NOI18N
        btn_enable.setText("  Enable");
        btn_enable.setBorderPainted(false);
        btn_enable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_enableMouseClicked(evt);
            }
        });
        btn_enable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_enableActionPerformed(evt);
            }
        });
        jPanel1.add(btn_enable, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 480, 220, 90));

        logout_button.setFont(new java.awt.Font("Arial", 1, 28)); // NOI18N
        logout_button.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\logout 72.png")); // NOI18N
        logout_button.setText("   LOGOUT");
        logout_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_buttonMouseClicked(evt);
            }
        });
        logout_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(logout_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(1640, 20, 260, 90));

        btn_disable.setFont(new java.awt.Font("Arial Narrow", 1, 30)); // NOI18N
        btn_disable.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\block 72.png")); // NOI18N
        btn_disable.setText("  Block");
        btn_disable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_disableMouseClicked(evt);
            }
        });
        btn_disable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_disableActionPerformed(evt);
            }
        });
        jPanel1.add(btn_disable, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 480, 220, 90));

        user_button.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        user_button.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\view add colored 72.png")); // NOI18N
        user_button.setText("  VIEW/ADD USERS");
        user_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                user_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                user_buttonMouseEntered(evt);
            }
        });
        user_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(user_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 600, 380, 90));

        jLabel10.setFont(new java.awt.Font("Arial Black", 1, 30)); // NOI18N
        jLabel10.setText("IP ADDRESS:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 170, -1, -1));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sessionButton.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        sessionButton.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\start new colored 72.png")); // NOI18N
        sessionButton.setText("   Start New Inventory");
        sessionButton.setToolTipText("");
        sessionButton.setBorderPainted(false);
        sessionButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        sessionButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sessionButtonMouseClicked(evt);
            }
        });
        sessionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sessionButtonActionPerformed(evt);
            }
        });
        jPanel3.add(sessionButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, 470, 100));

        cont_inv_button1.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        cont_inv_button1.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\preview colored 72.png")); // NOI18N
        cont_inv_button1.setText("  Preview Current Inventory");
        cont_inv_button1.setBorderPainted(false);
        cont_inv_button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cont_inv_button1ActionPerformed(evt);
            }
        });
        jPanel3.add(cont_inv_button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 470, 100));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 400, 570, 310));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\ip colored 72.png")); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 140, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\wifi colored 72.png")); // NOI18N
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 60, -1, -1));

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        insert_ip.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        insert_ip.setForeground(new java.awt.Color(255, 255, 255));
        insert_ip.setText("<insert ip>");
        jPanel4.add(insert_ip, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1120, 240, 570, 110));

        jLabel9.setFont(new java.awt.Font("Arial", 2, 18)); // NOI18N
        jLabel9.setText("Press on a connected user in the");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 500, -1, -1));

        jLabel11.setFont(new java.awt.Font("Arial", 2, 18)); // NOI18N
        jLabel11.setText("table and then click on either");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 520, -1, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 2, 18)); // NOI18N
        jLabel13.setText("Enable button or Block button:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 540, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 1920, 760));

        jPanel2.setMinimumSize(new java.awt.Dimension(1920, 224));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 55)); // NOI18N
        jLabel4.setText("Mobile Library Inventory Scanner");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, -1, -1));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 34)); // NOI18N
        jLabel1.setText("Desktop Application");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 80, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel5.setText("Fr. Jose T. Bacatan SJ Library");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 130, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\LIMS logo (200).png")); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\jtb logo (300).png")); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1610, 10, -1, -1));

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel8.setText("HOME");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 190, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 240));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sessionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sessionButtonActionPerformed
        Confirmation confirmation = new Confirmation("Start Inventory", IntroSession.this);
        confirmation.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        confirmation.show();
        dispose();
    }//GEN-LAST:event_sessionButtonActionPerformed

    private void sessionButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sessionButtonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sessionButtonMouseClicked

    private void cont_inv_button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cont_inv_button1ActionPerformed
        Table table;
        try {
            table = new Table();
            table.show();
            dispose();
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }//GEN-LAST:event_cont_inv_button1ActionPerformed

    private void btn_enableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_enableActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_enableActionPerformed

    private void btn_enableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_enableMouseClicked
        int id = (int) tbl_online_users.getValueAt(tbl_online_users.getSelectedRow(), 0);
        DBConfig dbconfig = new DBConfig();
        try {
            dbconfig.enableUser(id);
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btn_enableMouseClicked

    private void logout_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_buttonMouseClicked
        AdminLogin adminlogin = new AdminLogin();
        adminlogin.show();
        dispose();
        listener.stop();
    }//GEN-LAST:event_logout_buttonMouseClicked

    private void btn_disableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_disableMouseClicked
        int id = (int) tbl_online_users.getValueAt(tbl_online_users.getSelectedRow(), 0);
        DBConfig dbconfig = new DBConfig();
        try {
            dbconfig.disableUser(id);
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btn_disableMouseClicked

    private void user_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_buttonActionPerformed

    private void btn_disableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_disableActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_disableActionPerformed

    private void user_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_buttonMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_user_buttonMouseEntered

    private void user_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_user_buttonMouseClicked
        Confirmation confirmation = new Confirmation("View/Add Users", IntroSession.this);
        confirmation.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        confirmation.show();
        dispose();
    }//GEN-LAST:event_user_buttonMouseClicked

    private void logout_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_logout_buttonActionPerformed

    public static void main(String args[]) throws UnknownHostException, 
            SQLException {
        final IntroSession intro = new IntroSession();
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new IntroSession().setVisible(true);
                } catch (UnknownHostException ex) {
                    Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_disable;
    private javax.swing.JButton btn_enable;
    private javax.swing.JButton cont_inv_button1;
    private javax.swing.JLabel insert_ip;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_no_users;
    private javax.swing.JButton logout_button;
    private javax.swing.JButton sessionButton;
    private javax.swing.JTable tbl_online_users;
    private javax.swing.JButton user_button;
    // End of variables declaration//GEN-END:variables

}
