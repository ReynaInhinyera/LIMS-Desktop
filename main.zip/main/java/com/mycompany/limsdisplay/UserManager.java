package com.mycompany.limsdisplay;


import java.awt.Dialog;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import org.apache.commons.codec.digest.DigestUtils;

public class UserManager extends javax.swing.JFrame {
    private TableManager tm;
    private PGListener listener;
   
    public UserManager() throws SQLException {
        initComponents();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        showUsers();
        
        listener = new PGListener(tm, "manage");
        listener.start();
        
    }
    
    private void showUsers() throws SQLException {
        tm = new TableManager(users_table);
        tm.manageUsers(new DBConfig().getUsers());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        home_button = new javax.swing.JButton();
        deleteuser_button = new javax.swing.JButton();
        refresh_button = new javax.swing.JButton();
        changePass_button = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        name_tf = new javax.swing.JTextField();
        id_tf = new javax.swing.JTextField();
        pw_field = new javax.swing.JPasswordField();
        retypepw_field = new javax.swing.JPasswordField();
        new_user_button = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        users_table = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 380, 680, -1));

        jPanel2.setBackground(new java.awt.Color(51, 153, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        home_button.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 30)); // NOI18N
        home_button.setText("BACK TO HOME");
        home_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                home_buttonMouseClicked(evt);
            }
        });
        home_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                home_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(home_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 380, -1));

        deleteuser_button.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 30)); // NOI18N
        deleteuser_button.setText("Delete User");
        deleteuser_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                deleteuser_buttonMouseClicked(evt);
            }
        });
        deleteuser_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteuser_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(deleteuser_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 380, -1));

        refresh_button.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 30)); // NOI18N
        refresh_button.setText("Refresh Table");
        refresh_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                refresh_buttonMouseClicked(evt);
            }
        });
        jPanel2.add(refresh_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 380, -1));

        changePass_button.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 30)); // NOI18N
        changePass_button.setText("Change Password");
        changePass_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                changePass_buttonMouseClicked(evt);
            }
        });
        changePass_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changePass_buttonActionPerformed(evt);
            }
        });
        jPanel2.add(changePass_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 380, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 380, 760));

        jPanel3.setBackground(new java.awt.Color(0, 102, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 1, 34)); // NOI18N
        jLabel1.setText("CREATE NEW USER");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 10, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        jLabel2.setText("Name:");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        jLabel3.setText("ID:");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        jLabel4.setText("Password:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial Narrow", 1, 32)); // NOI18N
        jLabel5.setText("Retype Password:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 130, -1, -1));

        name_tf.setFont(new java.awt.Font("Arial", 0, 32)); // NOI18N
        jPanel3.add(name_tf, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, 330, -1));

        id_tf.setFont(new java.awt.Font("Arial", 0, 32)); // NOI18N
        jPanel3.add(id_tf, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 130, 330, -1));

        pw_field.setFont(new java.awt.Font("Arial", 0, 32)); // NOI18N
        jPanel3.add(pw_field, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 60, 330, -1));

        retypepw_field.setFont(new java.awt.Font("Arial", 0, 32)); // NOI18N
        retypepw_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retypepw_fieldActionPerformed(evt);
            }
        });
        jPanel3.add(retypepw_field, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 130, 330, -1));

        new_user_button.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        new_user_button.setText("Create");
        new_user_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new_user_buttonMouseClicked(evt);
            }
        });
        new_user_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                new_user_buttonActionPerformed(evt);
            }
        });
        jPanel3.add(new_user_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 240, 170, -1));

        jLabel12.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 0));
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 200, -1, -1));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 690, 1540, 310));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\LIMS logo (200).png")); // NOI18N
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\jtb logo (300).png")); // NOI18N
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1610, 10, -1, -1));

        jLabel8.setFont(new java.awt.Font("Arial Black", 0, 55)); // NOI18N
        jLabel8.setText("Mobile Library Inventory Scanner");
        jPanel4.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 0, -1, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 0, 34)); // NOI18N
        jLabel9.setText("Desktop Application");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 80, -1, -1));

        jLabel10.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        jLabel10.setText("Fr. Jose T. Bacatan SJ Library");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 130, -1, -1));

        jLabel11.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel11.setText("USER MANAGER");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 190, -1, -1));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 240));

        users_table.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        users_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Online Status", "Permission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        users_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                users_tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(users_table);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, 1540, 450));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void new_user_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_new_user_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_new_user_buttonActionPerformed

    private void home_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_home_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_home_buttonActionPerformed

    private void deleteuser_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteuser_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteuser_buttonActionPerformed

    private void home_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_home_buttonMouseClicked

        try {
            IntroSession introsession = new IntroSession();
            introsession.show();
            listener.stop();
            dispose();
        } catch (UnknownHostException ex) {
            Logger.getLogger(UserManager.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(UserManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_home_buttonMouseClicked

    private void new_user_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_new_user_buttonMouseClicked
        String name = name_tf.getText();
        String id = id_tf.getText();
        String password = "";
        
        if (pw_field.getText().equals(retypepw_field.getText())) {
            password = pw_field.getText();
            jLabel12.setText("");
        }
        else {
            jLabel12.setText("Passwords don't match.");
        }
        
        DBConfig dbconfig = new DBConfig();
        try {
            dbconfig.addUser(id, DigestUtils.md5Hex(password), name);
        } catch (SQLException ex) {
            Logger.getLogger(UserManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_new_user_buttonMouseClicked

    private void deleteuser_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteuser_buttonMouseClicked
        int id = (int) users_table.getValueAt(users_table.getSelectedRow(), 0);
        DBConfig dbconfig = new DBConfig();
        try {
            dbconfig.deleteUser(String.valueOf(id));
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteuser_buttonMouseClicked

    private void refresh_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_refresh_buttonMouseClicked
        try {
            showUsers();
        } catch (SQLException ex) {
            Logger.getLogger(UserManager.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_refresh_buttonMouseClicked

    private void users_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_users_tableMouseClicked

    }//GEN-LAST:event_users_tableMouseClicked

    private void changePass_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changePass_buttonMouseClicked
        int id = (int) users_table.getValueAt(users_table.getSelectedRow(), 0);
        PasswordDialog pwDialog = new PasswordDialog(id);
        pwDialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        pwDialog.show();
        this.setEnabled(rootPaneCheckingEnabled);
    }//GEN-LAST:event_changePass_buttonMouseClicked

    private void changePass_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changePass_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_changePass_buttonActionPerformed

    private void retypepw_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retypepw_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_retypepw_fieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserManager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new UserManager().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(UserManager.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton changePass_button;
    private javax.swing.JButton deleteuser_button;
    private javax.swing.JButton home_button;
    private javax.swing.JTextField id_tf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField name_tf;
    private javax.swing.JButton new_user_button;
    private javax.swing.JPasswordField pw_field;
    private javax.swing.JButton refresh_button;
    private javax.swing.JPasswordField retypepw_field;
    private javax.swing.JTable users_table;
    // End of variables declaration//GEN-END:variables
}
