
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Table extends javax.swing.JFrame {
    private TableManager tm;

    
    public Table() throws SQLException {
        initComponents();
        hideButtons();
        loadBooks("All sections");
    }
    
    private void loadBooks(String section) throws SQLException{             //load books of section
        tm = new TableManager(book_list_display);
        DBConfig dbc = new DBConfig();
        tm.addBook(dbc.getBooks(section), new DBConfig().getBarcodes());
    } 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        book_list_display = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        all_section_button = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        section_button = new javax.swing.JPanel();
        plus_sign = new javax.swing.JLabel();
        minus_sign = new javax.swing.JLabel();
        circulation_button = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        reference_button = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        filipiniana_button = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ac_button = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 153, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        book_list_display.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Barcodes", "Title Statement", "Call Number", "Total Number", "Number Scanned"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(book_list_display);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 5, 1030, 770));

        jPanel1.setBackground(new java.awt.Color(51, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        all_section_button.setBackground(new java.awt.Color(0, 153, 153));
        all_section_button.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        all_section_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                all_section_buttonMouseClicked(evt);
            }
        });
        all_section_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel3.setText("ALL SECTIONS");
        all_section_button.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel1.add(all_section_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 170, 50));

        section_button.setBackground(new java.awt.Color(0, 153, 153));
        section_button.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        section_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                section_buttonMouseClicked(evt);
            }
        });
        section_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        plus_sign.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\add-square-button (2).png")); // NOI18N
        section_button.add(plus_sign, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        minus_sign.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\minus-sign-on-a-square-outline.png")); // NOI18N
        section_button.add(minus_sign, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jPanel1.add(section_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 50, 50));

        circulation_button.setBackground(new java.awt.Color(102, 204, 255));
        circulation_button.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        circulation_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                circulation_buttonMouseClicked(evt);
            }
        });
        circulation_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\books.png")); // NOI18N
        circulation_button.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel5.setText("Circulation");
        circulation_button.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        jPanel1.add(circulation_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 220, 50));

        reference_button.setBackground(new java.awt.Color(102, 204, 255));
        reference_button.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        reference_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                reference_buttonMouseClicked(evt);
            }
        });
        reference_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\book-shelf.png")); // NOI18N
        reference_button.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel6.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel6.setText("Reference");
        reference_button.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        jPanel1.add(reference_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 220, 50));

        filipiniana_button.setBackground(new java.awt.Color(102, 204, 255));
        filipiniana_button.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        filipiniana_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                filipiniana_buttonMouseClicked(evt);
            }
        });
        filipiniana_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\philippines.png")); // NOI18N
        filipiniana_button.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel7.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel7.setText("Filipiniana");
        filipiniana_button.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        jPanel1.add(filipiniana_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 220, 50));

        ac_button.setBackground(new java.awt.Color(102, 204, 255));
        ac_button.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ac_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ac_buttonMouseClicked(evt);
            }
        });
        ac_button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\united-states.png")); // NOI18N
        ac_button.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel14.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel14.setText("American Corner");
        ac_button.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, -1, -1));

        jPanel1.add(ac_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 220, 50));

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jButton1.setText("Generate Final Report");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 220, 40));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 220, 580));

        jPanel2.setBackground(new java.awt.Color(51, 153, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel2.setText("LIMS");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, -1, 40));

        jLabel13.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\mavenproject1\\LIMSdisplay\\LIMS logo (circ).png")); // NOI18N
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 200));

        jPanel3.setBackground(new java.awt.Color(51, 153, 255));
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1250, 780));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            FinalInventory fininv = new FinalInventory();
            fininv.show();
            this.dispose();
        } catch (SQLException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void section_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_section_buttonMouseClicked
        if (circulation_button.isVisible()) {
            hideButtons();
        }
        else {
            showButtons();
        }
    }//GEN-LAST:event_section_buttonMouseClicked

    private void circulation_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_circulation_buttonMouseClicked
        try {
            loadBooks("Circulation");
        } catch (SQLException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_circulation_buttonMouseClicked

    private void filipiniana_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_filipiniana_buttonMouseClicked
        try {
            loadBooks("Filipiniana");
        } catch (SQLException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_filipiniana_buttonMouseClicked

    private void ac_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ac_buttonMouseClicked
        try {
            loadBooks("American Corner");
        } catch (SQLException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_ac_buttonMouseClicked

    private void reference_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_reference_buttonMouseClicked
        try {
            loadBooks("Reference");
        } catch (SQLException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_reference_buttonMouseClicked

    private void all_section_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_all_section_buttonMouseClicked
        try {
            loadBooks("All sections");
        } catch (SQLException ex) {
            Logger.getLogger(Table.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_all_section_buttonMouseClicked

    
    public static void main(String args[]) throws SQLException {
        final Table table = new Table();
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                    table.setVisible(true);
            }
        });
        
        PGListener listener = new PGListener(table.tm);
        listener.start();
    }
    
    
 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ac_button;
    private javax.swing.JPanel all_section_button;
    private javax.swing.JTable book_list_display;
    private javax.swing.JPanel circulation_button;
    private javax.swing.JPanel filipiniana_button;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel minus_sign;
    private javax.swing.JLabel plus_sign;
    private javax.swing.JPanel reference_button;
    private javax.swing.JPanel section_button;
    // End of variables declaration//GEN-END:variables

    private void hideButtons() {
        circulation_button.setVisible(false);
        reference_button.setVisible(false);
        filipiniana_button.setVisible(false);
        ac_button.setVisible(false);
        plus_sign.setVisible(true);
        minus_sign.setVisible(false);
    }
    
    private void showButtons() {
        circulation_button.setVisible(true);
        reference_button.setVisible(true);
        filipiniana_button.setVisible(true);
        ac_button.setVisible(true);
        plus_sign.setVisible(false);
        minus_sign.setVisible(true);
    }
}
