
import java.awt.Color;
import java.awt.Component;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class TableManager {
    
    private JTable book_list_display;

    public TableManager() {
    }

    public JTable getBook_list_display() {
        return book_list_display;
    }

    public void setBook_list_display(JTable book_list_display) {
        this.book_list_display = book_list_display;
    }

    public TableManager(JTable book_list_display) {
        this.book_list_display = book_list_display;
    }
    
    //scan status - "completed", "on progress"
    private DefaultTableModel setTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"Barcodes", "Title Statement", "Call Number", "Total Number", "Total Scanned", "Status", "Date & Time Scanned"};
        model.setColumnIdentifiers(header);      //sets the header
        book_list_display.setModel(model);
        return model;
    }
    
    public void addBook(ArrayList<Book> books, ArrayList<Barcode> barcodes) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setTable();
        
        for (Book book : books) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            
            String separator = "";
            StringBuilder barcodeBuilder = new StringBuilder();
            StringBuilder timestampBuilder = new StringBuilder();
            
            for (Barcode barcode : barcodes) {              //for each object (object barcode created) which was added in the collection, do code below it
                if (barcode.getBook_id() == book.getId()) {
                    barcodeBuilder.append(separator);
                    barcodeBuilder.append(barcode.getBarcode());
                    
                    timestampBuilder.append(separator);
                    timestampBuilder.append(barcode.getTimestamp());
                    separator = ", ";
                }
            }
            data.add(barcodeBuilder.toString());
            data.add(book.getTitle());
            data.add(book.getCall_no());
            data.add(book.getTotal_no());
            data.add(book.getScanned_no());
            
            if (book.getScanned_no() < book.getTotal_no()) {
                data.add("");
            }
            else {
                data.add("COMPLETE");
            }
            
            data.add(timestampBuilder.toString());
            model.addRow(data);
        }
        
        book_list_display.setDefaultRenderer(Object.class, new SetCellRenderer());
        
    }
    
    private static class SetCellRenderer implements TableCellRenderer {
        private DefaultTableCellRenderer renderer =  new DefaultTableCellRenderer();

        public SetCellRenderer() {
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, 
                Object value, boolean isSelected, boolean hasFocus, int row, 
                int column) {
            Component c = renderer.getTableCellRendererComponent(table, value, 
                    hasFocus, hasFocus, row, column);
            
            //changes color when that row is selected
            if(isSelected){
                    c.setBackground(Color.YELLOW);
                    c.setForeground(Color.BLACK);

            //alternates color each row by default
            } else {
                if (row%2 == 0){
                    c.setBackground(Color.WHITE);

                }
                else {
                    c.setBackground(Color.CYAN);
                }     
            }
            

///////////CHANGE THE "PUBLISHED?" to whatever you named in the header
       
            if(table.getColumnModel().getColumn(column).getIdentifier()
                    .equals("Status")){
                if(value.toString().equals("COMPLETE")){
                    c.setBackground(Color.GREEN);
                }
                else {
                    c.setBackground(Color.RED);
                }
            }
            
            return c;
        }
    }
    
    private DefaultTableModel setTableFinal() {
        DefaultTableModel finalmodel = new DefaultTableModel (0, 0);
        String header[] = new String[]{"Title Statement", "Call Number", "Barcode", "Section"};
        finalmodel.setColumnIdentifiers(header);      //sets the header
        book_list_display.setModel(finalmodel);
        return finalmodel;
    }
    
    public void addBookFinal() throws SQLException {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setTableFinal();
        
        ArrayList<Book> books = new DBConfig().getBooks("All sections");
        ArrayList<Barcode> barcodes = new DBConfig().getBarcodes();
        
        for (Book book : books) {       //for each - for unknown count in array; for each scans through the whole collection
            for (Barcode barcode : barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned())
                {
                    Vector<Object> data = new Vector<Object>();

                    data.add(book.getTitle());
                    data.add(book.getCall_no());
                    data.add(barcode.getBarcode());
                    data.add(book.getSection());
            
                    model.addRow(data);
                }
            }
            
        }
        
    }
    
    
}
