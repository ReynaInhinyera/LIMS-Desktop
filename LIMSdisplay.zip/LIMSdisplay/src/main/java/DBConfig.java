
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class DBConfig {
    
    private Connection c;         //Connection connects to postgre database
    private Statement stmt;            //Statement - what to do; request; CRUD

    public DBConfig() {
        try {
         Class.forName("org.postgresql.Driver");
         c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/db_inventory",
            "postgres", "pgadmin");
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }         //try - try the code; catch - catches the error
      System.out.println("Opened database successfully");
    }

    public DBConfig(Connection c) {        
        try {
         Class.forName("org.postgresql.Driver");
         this.c = c;
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }
      System.out.println("Opened database successfully");
    }
    
    public ArrayList<Book> getBooks(String section) throws SQLException {             //this whole does SQL database operation. if there are any errors, there is an automatic catch or disregards error.
        stmt = c.createStatement();                     //create request
        ResultSet rs;
        
        if (section.equals("All sections")) {
            rs = stmt.executeQuery("SELECT id, title, total_no, no_scanned, call_no, section " 
                + "FROM public.tbl_inventory AS inv "
                + "ORDER BY \"timestamp\" DESC;");         //execute request or statement
        }
        else {
            rs = stmt.executeQuery("SELECT id, title, total_no, no_scanned, call_no, section " 
                + "FROM public.tbl_inventory "
                + "WHERE section = '" + section + "' "
                + "ORDER BY \"timestamp\" DESC;");         //execute request or statement
        }
        
        ArrayList<Book> books = new ArrayList<Book>();
        
        while (rs.next()) {             //while there is still a next row, it will execute this loop
            Book book = new Book();                 //create new object
            
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setTotal_no(rs.getInt("total_no"));
            book.setScanned_no(rs.getInt("no_scanned"));
            book.setCall_no(rs.getString("call_no"));
            book.setSection(rs.getString("section"));   //these six sets values
            books.add(book);        //puts inside the new created collection (arraylist)
        }
        
        rs.close();
        stmt.close();
        c.close();
        //these three indicates that the query has ended
        
        System.out.println("Get books done successfully!");
        
        return books;
    }
    
    public ArrayList<Barcode> getBarcodes() throws SQLException {
        stmt = c.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT barcode, book_id, \"timestamp\", is_scanned "
                + "FROM tbl_barcode;");
        ArrayList<Barcode> barcodes = new ArrayList<Barcode>();
        
        while (rs.next()) {
            Barcode barcode = new Barcode();
            barcode.setBarcode(rs.getString("barcode"));
            barcode.setBook_id(rs.getInt("book_id"));
            barcode.setTimestamp(rs.getTimestamp("timestamp"));
            
            if (rs.getString("is_scanned").equals("1")){
                barcode.setIs_Scanned(true);
            } else if (rs.getString("is_scanned").equals("0")){
                barcode.setIs_Scanned(false);
            }
            
            barcodes.add(barcode);              //<name of collection>.add(what is done before)
        }
        
        rs.close();
        stmt.close();
        c.close();
        
        System.out.println("Get barcodes done successfully");
        
        return barcodes;
    }
    
    public void startNewInventory() throws SQLException {
        stmt = c.createStatement();   
        stmt.executeUpdate("UPDATE public.tbl_inventory "
            + "SET no_scanned='0'; ");
        
        stmt.close();
        c.close();
    }
    
    public void startNewBarcode() throws SQLException {
        stmt = c.createStatement();       
        stmt.executeUpdate("UPDATE public.tbl_barcode "
            + "SET is_scanned='0'; ");
        
        stmt.close();
        c.close();
    }
    
    public MissingBooks getBooksFinal() throws SQLException {             //this whole does SQL database operation. if there are any errors, there is an automatic catch or disregards error.
        stmt = c.createStatement();                     //create request
        ResultSet rs;
        
        rs = stmt.executeQuery("SELECT id, title, br.barcode, call_no, section "
            + "FROM tbl_inventory AS inv " 
            + "INNER JOIN tbl_barcode AS br "
            + "ON br.book_id = inv.id "
            + "WHERE br.is_scanned = '0' "); 
        
        MissingBooks missing_books = new MissingBooks();
        
        ArrayList<Book> books = new ArrayList<Book>();
        ArrayList<Barcode> barcodes = new ArrayList<Barcode>();
        
        while (rs.next()) {             //while there is still a next row, it will execute this loop
            Book book = new Book();                 //create new object
            Barcode barcode = new Barcode();
            
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setCall_no(rs.getString("call_no"));
            book.setSection(rs.getString("section"));
            barcode.setBook_id(rs.getInt("id"));
            barcode.setBarcode(rs.getString("barcode"));
            barcodes.add(barcode);
            books.add(book);        //puts inside the new created collection (arraylist)
        }
        
        missing_books.setBarcodes(barcodes);
        missing_books.setBooks(books);
        
        rs.close();
        stmt.close();
        c.close();
        //these three indicates that the query has ended
        
        System.out.println("Final inventory generated!");
        
        return missing_books;
    }
}
